package io.zhc1.realworld.model;

import java.util.List;
import java.util.Optional;

public interface ArticleCommentRepository {
    ArticleComment save(ArticleComment articleComment);

    Optional<ArticleComment> findById(int commentId);

    List<ArticleComment> findByArticle(Article article);

    void delete(ArticleComment articleComment);
}
